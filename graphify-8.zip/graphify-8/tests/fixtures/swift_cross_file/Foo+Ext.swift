extension Foo {
    func two() {}
}
