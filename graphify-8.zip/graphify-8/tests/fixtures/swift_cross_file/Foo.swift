class Foo {
    func one() {}
}
