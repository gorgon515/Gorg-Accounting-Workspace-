# Prepare Windows for NemoClaw

import { AgentOnly } from "../_components/AgentGuide";

You can run NemoClaw inside Windows Subsystem for Linux (WSL 2) on Windows.
<AgentOnly variant="openclaw">
Complete these steps before following the Quickstart.
</AgentOnly>
<AgentOnly variant="hermes">
Complete these steps before following Quickstart with Hermes.
</AgentOnly>
Linux and macOS users do not need this page and can go directly to the Quickstart.

**Note:**

NVIDIA tested this guide on x86-64.

## Prerequisites

Verify the following before you begin:

- Windows 10 (build 19041 or later) or Windows 11.
<AgentOnly variant="openclaw">

- Hardware requirements are the same as the Quickstart.

</AgentOnly>
<AgentOnly variant="hermes">

- Hardware requirements are the same as Quickstart with Hermes.

</AgentOnly>

## Option: Use the Bootstrap Script

Open Windows PowerShell on the Windows host and run the bootstrap script:

```powershell
Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/NVIDIA/NemoClaw/main/scripts/bootstrap-windows.ps1' -OutFile "$env:TEMP\bootstrap-windows.ps1"; powershell.exe -ExecutionPolicy Bypass -File "$env:TEMP\bootstrap-windows.ps1"
```

The command downloads the script to a temporary file before running it.
`-ExecutionPolicy Bypass` applies only to that PowerShell process and avoids local policy blocking the downloaded script.
Run it from Windows, not from inside WSL.
The script requests Administrator privileges when needed, enables the required WSL 2 Windows features, installs or opens Ubuntu 24.04, and installs and starts Docker Desktop.
When Ubuntu needs first-run account setup, the script opens a handoff window and waits for that account to exist before it changes Docker settings.
It enables Docker Desktop WSL integration for the target distro, restarts Docker Desktop only when Docker was already running, and leaves your global default WSL distro unchanged.
If the target Ubuntu distro is already registered, the script confirms it uses WSL 2, converts it from WSL 1 when needed, and verifies Docker is reachable from WSL.
If Windows requires a reboot after enabling WSL features, the script prompts for the reboot and registers a one-time continuation for the next sign-in.
If Docker Desktop shows first-run prompts, complete them and return to the PowerShell window.

For advanced options, download the script first and run `Get-Help "$env:TEMP\bootstrap-windows.ps1" -Detailed`.
Useful parameters include `-DistroName`, `-InstallerUrl`, `-InstallerArgs`, and `-InstallDockerDesktop`.
The default distro is `Ubuntu-24.04`.
To reuse an existing distro named `Ubuntu`, pass `-DistroName Ubuntu`.

The bootstrap script does not install NemoClaw itself.
When Windows preparation is complete, it opens Ubuntu and prints the standard installer command to run inside Ubuntu:

```bash
curl -fsSL https://www.nvidia.com/nemoclaw.sh | bash
```

If the bootstrap script reports that Ubuntu cannot reach Docker, open Docker Desktop Settings and confirm that Docker Desktop enables WSL integration for Ubuntu (**Settings** > **Resources** > **WSL integration**), make sure Docker Desktop is running, then rerun the script.

If the bootstrap script reports that `winget.exe` is not available (common on Windows Server or stripped Windows installs), install **App Installer** from the Microsoft Store (which provides `winget`), or download and install Docker Desktop manually from [docker.com](https://www.docker.com/products/docker-desktop/).
After you install Docker Desktop, rerun the bootstrap script.
The script skips the install step after it detects Docker Desktop.

The manual steps below describe the same Windows preparation pieces and are useful when you need to verify or repair WSL, Ubuntu, or Docker Desktop by hand.

## Enable WSL 2

Open an elevated PowerShell (Run as Administrator):

```powershell
wsl --install --no-distribution
```

This enables both the Windows Subsystem for Linux and Virtual Machine Platform features.

Reboot if prompted.

## Install and Register Ubuntu

After reboot, open an elevated PowerShell again:

```powershell
wsl --install -d Ubuntu-24.04
```

Let the distribution launch and complete first-run setup (pick a Unix username and password), then type `exit` to return to PowerShell.

**Warning:**

Do not use the `--no-launch` flag.
The `--no-launch` flag downloads the package but does not register the distribution with WSL.
Commands like `wsl -d Ubuntu-24.04` fail with "There is no distribution with the supplied name" until you launch the distribution at least one time.

Verify that WSL registered the distribution and runs it with WSL 2:

```powershell
wsl -l -v
```

Expected output:

```text
  NAME            STATE           VERSION
* Ubuntu-24.04    Running         2
```

## Install Docker Desktop

Install [Docker Desktop](https://www.docker.com/products/docker-desktop/) with the WSL 2 backend (the default on Windows 11).

After installation, open Docker Desktop Settings and confirm that Docker Desktop enables WSL integration for your Ubuntu distribution (**Settings** > **Resources** > **WSL integration**).

Open WSL from PowerShell:

```powershell
wsl
```

Then verify Docker from inside WSL:

```bash
docker info
```

`docker info` prints server information.
If you see "Cannot connect to the Docker daemon", confirm that Docker Desktop is running and that Docker Desktop enables WSL integration.

## Set Up Local Inference with Ollama (Optional)

If you plan to select Ollama as your inference provider during onboarding, use one Ollama instance that WSL can reach.
You can install Ollama inside WSL yourself:

```bash
curl -fsSL https://ollama.com/install.sh | sh
```

If you installed Ollama but it is not already running in WSL, onboarding starts it for you.
You can also start it yourself beforehand with `ollama serve`.

You can also use Ollama for Windows.
During onboarding, NemoClaw can use an already-running Windows-host daemon, start or restart an installed daemon, or install Ollama on the Windows host.
If the installer offers express install on WSL, accepting it selects this Windows-host Ollama path automatically.
When Ollama runs on the Windows host, NemoClaw detects it from WSL through `host.docker.internal` and pulls missing models through the Ollama HTTP API.
Do not run both the Windows and WSL Ollama instances on port `11434` at the same time.
Use one instance, or move one of them to a different port before running `nemoclaw onboard`.

## Next Step

Your Windows environment is ready.
If you used the bootstrap script, follow the installer command it printed inside Ubuntu.
<AgentOnly variant="openclaw">
If you prepared Windows manually, open a WSL terminal (type `wsl` in PowerShell, or open Ubuntu from Windows Terminal) and continue with the Quickstart to install NemoClaw and launch your first sandbox.
</AgentOnly>
<AgentOnly variant="hermes">
If you prepared Windows manually, open a WSL terminal (type `wsl` in PowerShell, or open Ubuntu from Windows Terminal) and continue with Quickstart with Hermes to install NemoClaw and launch your first Hermes sandbox.
</AgentOnly>

All NemoClaw commands run inside WSL, not in PowerShell.

## Troubleshooting

For Windows-specific troubleshooting, refer to the Windows Subsystem for Linux section in the Troubleshooting guide.
