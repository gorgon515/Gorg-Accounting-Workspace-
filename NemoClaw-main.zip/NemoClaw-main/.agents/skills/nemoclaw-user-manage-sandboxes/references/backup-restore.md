# Backup and Restore Workspace Files

import { AgentOnly } from "../_components/AgentGuide";

Workspace and state files define your agent's personality, memory, user context, and durable runtime state.
They persist across sandbox restarts but are **permanently deleted** when you destroy the sandbox.

This guide covers snapshot commands, manual backup with CLI commands, and an automated script.

## When to Back Up

<AgentOnly variant="openclaw">

- Before running `nemoclaw <name> destroy`
- Before major NemoClaw version upgrades
- Periodically, if you've invested time customizing your agent

</AgentOnly>
<AgentOnly variant="hermes">

- Before running `nemoclaw <name> destroy`
- Before major NemoClaw version upgrades
- Periodically, if you've invested time customizing your agent or paired messaging channels

</AgentOnly>

## Snapshot Commands

The fastest way to back up and restore sandbox state is with the built-in snapshot commands.
Snapshots capture all workspace state directories defined in the agent manifest and store them in `~/.nemoclaw/rebuild-backups/<name>/`.
Agent manifests can also declare durable top-level state files.
For Hermes, snapshots include `SOUL.md` and the SQLite database behind `.hermes/state.db` using SQLite's online backup API, then restore that database through SQLite instead of copying a live raw database file.
Treat snapshot directories as private local data: the Hermes database can contain session metadata and message history needed for a faithful restore.

```bash
nemoclaw my-assistant snapshot create
nemoclaw my-assistant snapshot list
nemoclaw my-assistant snapshot restore
```

`snapshot list` prints a table of version, name, timestamp, and path.
NemoClaw computes versions (`v1`, `v2`, ..., `vN`) from timestamp order, so `vN` is always the newest snapshot.

To tag a snapshot with a human-readable label, pass `--name`:

```bash
nemoclaw my-assistant snapshot create --name before-upgrade
```

To restore a specific snapshot instead of the latest, pass a version, name, or timestamp prefix:

```bash
nemoclaw my-assistant snapshot restore v3
nemoclaw my-assistant snapshot restore before-upgrade
nemoclaw my-assistant snapshot restore 2026-04-14T
```

To clone a snapshot into a different sandbox name, pass `--to <name>`.
If the destination sandbox already exists, NemoClaw refuses to overwrite it unless you pass `--force`:

```bash
nemoclaw my-assistant snapshot restore before-upgrade --to my-assistant-clone
nemoclaw my-assistant snapshot restore before-upgrade --to my-assistant-clone --force --yes
```

<AgentOnly variant="openclaw">

The `nemoclaw <name> rebuild` command uses the same snapshot mechanism automatically.
Snapshot restore performs a targeted repair for legacy `.openclaw-data` symlinks that older images created.
NemoClaw rejects unsafe symlinks and hard links inside sandbox state during backup creation before they can enter a snapshot.

</AgentOnly>
<AgentOnly variant="hermes">

The `nemoclaw <name> rebuild` command uses the same snapshot mechanism automatically.
NemoClaw rejects unsafe symlinks and hard links inside sandbox state during backup creation before they can enter a snapshot.
Credential-bearing Hermes files such as `auth.json` are intentionally excluded
from snapshots. NemoClaw-regenerated Hermes config files (`config.yaml` and
`.env`) are also excluded; model/provider and messaging credentials are
recreated from host-side onboarding and OpenShell provider state during rebuild.

</AgentOnly>
For full details, see the Commands reference (use the `nemoclaw-user-reference` skill).

## Manual Backup

Use `openshell sandbox download` to copy files from the sandbox to your host.

<AgentOnly variant="openclaw">

```bash
SANDBOX=my-assistant
BACKUP_DIR=~/.nemoclaw/backups/$(date +%Y%m%d-%H%M%S)
mkdir -p "$BACKUP_DIR"

openshell sandbox download "$SANDBOX" /sandbox/.openclaw/workspace/SOUL.md "$BACKUP_DIR/"
openshell sandbox download "$SANDBOX" /sandbox/.openclaw/workspace/USER.md "$BACKUP_DIR/"
openshell sandbox download "$SANDBOX" /sandbox/.openclaw/workspace/IDENTITY.md "$BACKUP_DIR/"
openshell sandbox download "$SANDBOX" /sandbox/.openclaw/workspace/AGENTS.md "$BACKUP_DIR/"
openshell sandbox download "$SANDBOX" /sandbox/.openclaw/workspace/MEMORY.md "$BACKUP_DIR/"
openshell sandbox download "$SANDBOX" /sandbox/.openclaw/workspace/memory/ "$BACKUP_DIR/memory/"
```

</AgentOnly>
<AgentOnly variant="hermes">

```bash
SANDBOX=my-hermes
BACKUP_DIR=~/.nemoclaw/backups/$(date +%Y%m%d-%H%M%S)
mkdir -p "$BACKUP_DIR"

openshell sandbox download "$SANDBOX" /sandbox/SOUL.md "$BACKUP_DIR/"
openshell sandbox download "$SANDBOX" /sandbox/.hermes/state.db "$BACKUP_DIR/"
openshell sandbox download "$SANDBOX" /sandbox/.hermes/platforms/ "$BACKUP_DIR/platforms/"
```

</AgentOnly>

## Manual Restore

Use `openshell sandbox upload` to push files back into a sandbox.

<AgentOnly variant="openclaw">

```bash
SANDBOX=my-assistant
BACKUP_DIR=~/.nemoclaw/backups/20260320-120000  # pick a timestamp

openshell sandbox upload "$SANDBOX" "$BACKUP_DIR/SOUL.md" /sandbox/.openclaw/workspace/
openshell sandbox upload "$SANDBOX" "$BACKUP_DIR/USER.md" /sandbox/.openclaw/workspace/
openshell sandbox upload "$SANDBOX" "$BACKUP_DIR/IDENTITY.md" /sandbox/.openclaw/workspace/
openshell sandbox upload "$SANDBOX" "$BACKUP_DIR/AGENTS.md" /sandbox/.openclaw/workspace/
openshell sandbox upload "$SANDBOX" "$BACKUP_DIR/MEMORY.md" /sandbox/.openclaw/workspace/
openshell sandbox upload "$SANDBOX" "$BACKUP_DIR/memory/" /sandbox/.openclaw/workspace/memory/
```

</AgentOnly>
<AgentOnly variant="hermes">

```bash
SANDBOX=my-hermes
BACKUP_DIR=~/.nemoclaw/backups/20260320-120000  # pick a timestamp

openshell sandbox upload "$SANDBOX" "$BACKUP_DIR/SOUL.md" /sandbox/
openshell sandbox upload "$SANDBOX" "$BACKUP_DIR/state.db" /sandbox/.hermes/
openshell sandbox upload "$SANDBOX" "$BACKUP_DIR/platforms/" /sandbox/.hermes/platforms/
```

</AgentOnly>

## Using the Backup Script

<AgentOnly variant="openclaw">

The repository includes a convenience script at `scripts/backup-workspace.sh`.

### Backup

```console
$ ./scripts/backup-workspace.sh backup my-assistant
Backing up workspace from sandbox 'my-assistant'...
Backup saved to /home/user/.nemoclaw/backups/20260320-120000/ (6 items)
```

### Restore

Restore from the most recent backup:

```bash
./scripts/backup-workspace.sh restore my-assistant
```

Restore from a specific timestamp:

```bash
./scripts/backup-workspace.sh restore my-assistant 20260320-120000
```

## Verifying a Backup

List backed-up files to confirm completeness:

```console
$ ls -la ~/.nemoclaw/backups/20260320-120000/
AGENTS.md
IDENTITY.md
MEMORY.md
SOUL.md
USER.md
memory/
```

</AgentOnly>
<AgentOnly variant="hermes">

For Hermes, prefer the built-in snapshot commands for faithful restore of `state.db`.
Use manual `openshell sandbox download` / `openshell sandbox upload` only when you need to inspect or transfer a specific file.

</AgentOnly>

<AgentOnly variant="openclaw">

## Multi-Agent Deployments

When you configure OpenClaw with multiple named agents, each agent has its own workspace directory (`workspace-main/`, `workspace-support/`, `workspace-ops/`, and so on).
Refer to [Multi-Agent Deployments](workspace-files.md#multi-agent-deployments).

`nemoclaw <name> snapshot create` automatically discovers every `workspace-*/` directory under the sandbox state tree and includes it in the snapshot bundle alongside the default `workspace/`.
`snapshot restore` reapplies the full per-agent set.
You do not need a manual per-workspace backup pattern.

The sandbox entrypoint ensures every per-agent workspace lives directly under the persistent `.openclaw/` tree, so state also survives `openshell sandbox restart`.

### Shared files across agents

Files that operators typically want consistent across every per-agent workspace
(`AGENTS.md`, shared skills, common templates) are **not** synced automatically.
Each workspace is independent, and changes in one do not propagate.
Operators that need this either copy the shared files explicitly to each workspace after editing or maintain a host-side sync layer.
NVIDIA tracks shared-file tooling (shared mount, `workspaces list` command) in [#1260](https://github.com/NVIDIA/NemoClaw/issues/1260).

</AgentOnly>
<AgentOnly variant="hermes">

## Hermes State

Hermes does not use OpenClaw per-agent workspace directories.
NemoClaw snapshots preserve the Hermes manifest-defined state tree and durable top-level files instead.
Refer to [Workspace Files](workspace-files.md) for the Hermes state layout.

</AgentOnly>

## Next Steps

- [Workspace Files overview](workspace-files.md) to learn what each file does.
- Commands reference (use the `nemoclaw-user-reference` skill)
